import React, { useState } from 'react';
import './PlayerSearch.css';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

function PlayerSearch({ players, sport }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPlayer, setSelectedPlayer] = useState(null);
  const [playerDetails, setPlayerDetails] = useState(null);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [error, setError] = useState(null);

  const filteredPlayers = players.filter(player =>
    player.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    player.country.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const fetchPlayerDetails = async (playerId) => {
    try {
      setLoadingDetails(true);
      setError(null);
      setPlayerDetails(null);

      const endpoint = sport === 'cricket'
        ? `http://localhost:5000/api/athletes/${playerId}`
        : `http://localhost:5000/api/footballers/${playerId}`;

      console.log('Fetching from:', endpoint);
      const response = await fetch(endpoint);

      if (!response.ok) {
        throw new Error(`Failed to fetch: ${response.status}`);
      }

      const data = await response.json();
      console.log('Received data:', data);

      setPlayerDetails(data);
      setSelectedPlayer(playerId);
    } catch (error) {
      console.error('Error:', error);
      setError(error.message);
    } finally {
      setLoadingDetails(false);
    }
  };

  // Safe chart data preparation with position-specific metrics
  const getLineChartData = () => {
    if (!playerDetails?.stats || playerDetails.stats.length === 0) return [];

    if (sport === 'cricket') {
      const role = playerDetails.role;
      
      if (role === 'Batter' || role === 'Wicket-keeper' || role === 'batter' || role === 'wicketkeeper') {
        // Show batting average for batters
        return playerDetails.stats.map(stat => ({
          format: stat.format || 'N/A',
          batting_avg: parseFloat(stat.batting_avg) || 0,
          strike_rate: parseFloat(stat.strike_rate) || 0
        }));
      } else if (role === 'Bowler' || role === 'bowler') {
        // Show wickets per format for bowlers
        return playerDetails.stats.map(stat => ({
          format: stat.format || 'N/A',
          wickets: parseFloat(stat.wickets) || 0,
          bowling_avg: parseFloat(stat.bowling_avg) || 0
        }));
      } else {
        // All-rounder: show batting avg and wickets per match
        return playerDetails.stats.map(stat => ({
          format: stat.format || 'N/A',
          batting_avg: parseFloat(stat.batting_avg) || 0,
          wickets_per_match: stat.matches > 0 ? ((parseFloat(stat.wickets) || 0) / stat.matches).toFixed(2) : 0
        }));
      }
    } else {
      const position = playerDetails.position;
      
      if (position === 'Forward') {
        // Show goals per game for forwards
        return playerDetails.stats.map(stat => ({
          season: stat.season || 'N/A',
          goals: stat.matches > 0 ? ((parseFloat(stat.goals) || 0) / stat.matches).toFixed(2) : 0,
          assists: parseFloat(stat.assists) || 0
        }));
      } else if (position === 'Midfielder') {
        // Show tackles per game for midfielders
        return playerDetails.stats.map(stat => ({
          season: stat.season || 'N/A',
          tackles_per_game: stat.matches > 0 ? ((parseFloat(stat.tackles) || 0) / stat.matches).toFixed(1) : 0,
          assists: parseFloat(stat.assists) || 0
        }));
      } else if (position === 'Defender') {
        // Show tackles per game for defenders
        return playerDetails.stats.map(stat => ({
          season: stat.season || 'N/A',
          tackles_per_game: stat.matches > 0 ? ((parseFloat(stat.tackles) || 0) / stat.matches).toFixed(1) : 0,
          clean_sheets: parseFloat(stat.clean_sheets) || 0
        }));
      } else {
        // Goalkeeper: show saves per game
        return playerDetails.stats.map(stat => ({
          season: stat.season || 'N/A',
          saves: stat.matches > 0 ? ((parseFloat(stat.saves) || 0) / stat.matches).toFixed(1) : 0,
          clean_sheets: parseFloat(stat.clean_sheets) || 0
        }));
      }
    }
  };

  const lineChartData = getLineChartData();

  return (
    <div className="player-search-container">
      <div className="search-section">
        <div className="search-header">
          <input
            type="text"
            placeholder={`Search ${sport} players from database...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
          <div className="data-info">
            <span className="data-badge">
              💾 <strong>Database:</strong> {sport === 'cricket' ? 'cricket_performance' : 'football_performance'}
            </span>
          </div>
        </div>
      </div>

      <div className="search-results">
        {searchTerm && filteredPlayers.length === 0 && (
          <div className="no-results">😕 No players found</div>
        )}

        <div className="players-list">
          {filteredPlayers.slice(0, 50).map(player => {
            const playerId = player.athlete_id || player.footballer_id;
            return (
              <div
                key={playerId}
                className="player-card"
                onClick={() => fetchPlayerDetails(playerId)}
                style={{
                  backgroundColor: selectedPlayer === playerId ? '#e3f2fd' : '#f5f5f5',
                  borderLeft: selectedPlayer === playerId ? '4px solid #2196F3' : 'none'
                }}
              >
                <div className="player-name">{player.name}</div>
                <div className="player-info">
                  <span className="country-badge">🌍 {player.country}</span>
                  <span className="role-badge">
                    {sport === 'cricket' ? (player.role || 'N/A') : (player.position || 'N/A')}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="details-section">
        {error && (
          <div className="error-message">
            <strong>⚠️ Error:</strong> {error}
          </div>
        )}

        {loadingDetails && (
          <div className="loading">⏳ Loading player details...</div>
        )}

        {playerDetails && !loadingDetails && (
          <div className="player-details-card">
            <div className="details-header">
              <h2>{playerDetails.name}</h2>
              <div className="header-info">
                <span>🌍 {playerDetails.country}</span>
                <span>Age: {playerDetails.age}</span>
                <span>{sport === 'cricket' ? playerDetails.role : playerDetails.position}</span>
              </div>
            </div>

            {/* Performance Rating Circle */}
            {playerDetails.metrics && (
              <div className="performance-section">
                <h3>📊 Overall Performance Rating</h3>
                <div className="final-rating">
                  <div className="rating-circle">
                    <div className="rating-value">
                      {playerDetails.metrics.final_rating}
                    </div>
                    <div className="rating-label">Out of 100</div>
                  </div>
                </div>
                <div className="rating-description">
                  <div className="metric-detail">
                    <span className="icon">💪</span>
                    <span>Performance: {playerDetails.metrics.performance_score || playerDetails.metrics.overall_performance}</span>
                  </div>
                  <div className="metric-detail">
                    <span className="icon">🏥</span>
                    <span>Injury Impact: {playerDetails.metrics.injury_impact}</span>
                  </div>
                  <div className="metric-detail">
                    <span className="icon">❤️</span>
                    <span>Fitness Level: {playerDetails.metrics.fitness_level}%</span>
                  </div>
                </div>
              </div>
            )}

            {/* Statistics */}
            {playerDetails.metrics && (
              <div className="stats-summary">
                <h3>📈 Career Statistics</h3>
                <div className="stats-grid">
                  {sport === 'cricket' ? (
                    <>
                      <div className="stat-item">
                        <div className="stat-label">Matches</div>
                        <div className="stat-value">{playerDetails.metrics.total_matches}</div>
                      </div>
                      <div className="stat-item">
                        <div className="stat-label">Runs</div>
                        <div className="stat-value">{playerDetails.metrics.total_runs}</div>
                      </div>
                      <div className="stat-item">
                        <div className="stat-label">Wickets</div>
                        <div className="stat-value">{playerDetails.metrics.total_wickets}</div>
                      </div>
                      <div className="stat-item">
                        <div className="stat-label">Avg Batting</div>
                        <div className="stat-value">{playerDetails.metrics.avg_batting}</div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="stat-item">
                        <div className="stat-label">Matches</div>
                        <div className="stat-value">{playerDetails.metrics.total_matches}</div>
                      </div>
                      <div className="stat-item">
                        <div className="stat-label">Goals</div>
                        <div className="stat-value">{playerDetails.metrics.total_goals}</div>
                      </div>
                      <div className="stat-item">
                        <div className="stat-label">Assists</div>
                        <div className="stat-value">{playerDetails.metrics.total_assists}</div>
                      </div>
                      <div className="stat-item">
                        <div className="stat-label">Pass Acc</div>
                        <div className="stat-value">{playerDetails.metrics.avg_pass_accuracy}%</div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}

            {/* Position-Specific Performance Bar Chart */}
            {playerDetails.stats && playerDetails.stats.length > 0 && (
              <div className="chart-section">
                <h3>📊 Position-Specific Performance</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={lineChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey={sport === 'cricket' ? 'format' : 'season'} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    {sport === 'cricket' ? (
                      playerDetails.role === 'Batter' || playerDetails.role === 'Wicket-keeper' || playerDetails.role === 'batter' || playerDetails.role === 'wicketkeeper' ? (
                        <>
                          <Bar dataKey="batting_avg" fill="#FF6B6B" name="Batting Average">
                            {lineChartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={`rgba(255, 107, 107, ${0.6 + (index * 0.1)})`} />
                            ))}
                          </Bar>
                        </>
                      ) : playerDetails.role === 'Bowler' || playerDetails.role === 'bowler' ? (
                        <>
                          <Bar dataKey="wickets" fill="#4ECDC4" name="Wickets per Format">
                            {lineChartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={`rgba(78, 205, 196, ${0.6 + (index * 0.1)})`} />
                            ))}
                          </Bar>
                        </>
                      ) : (
                        <>
                          <Bar dataKey="batting_avg" fill="#FF6B6B" name="Batting Average" />
                          <Bar dataKey="wickets_per_match" fill="#4ECDC4" name="Wickets/Match" />
                        </>
                      )
                    ) : (
                      playerDetails.position === 'Forward' ? (
                        <>
                          <Bar dataKey="goals" fill="#FF6B6B" name="Goals per Game">
                            {lineChartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={`rgba(255, 107, 107, ${0.6 + (index * 0.1)})`} />
                            ))}
                          </Bar>
                        </>
                      ) : playerDetails.position === 'Midfielder' ? (
                        <>
                          <Bar dataKey="tackles_per_game" fill="#FFB347" name="Tackles/Game" />
                          <Bar dataKey="assists" fill="#4ECDC4" name="Assists" />
                        </>
                      ) : playerDetails.position === 'Defender' ? (
                        <>
                          <Bar dataKey="tackles_per_game" fill="#95E1D3" name="Tackles per Game">
                            {lineChartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={`rgba(149, 225, 211, ${0.6 + (index * 0.1)})`} />
                            ))}
                          </Bar>
                        </>
                      ) : (
                        <>
                          <Bar dataKey="saves" fill="#9B59B6" name="Saves per Game">
                            {lineChartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={`rgba(155, 89, 182, ${0.6 + (index * 0.1)})`} />
                            ))}
                          </Bar>
                        </>
                      )
                    )}
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Injuries */}
            <div className="injuries-section">
              <h3>🏥 Injury Status</h3>
              {playerDetails.injuries && playerDetails.injuries.length > 0 ? (
                <div className="injuries-list">
                  {playerDetails.injuries.map((injury, idx) => (
                    <div key={idx} className="injury-card">
                      <div className="injury-type">{injury.injury_type}</div>
                      <div className="injury-info">
                        <span>{new Date(injury.injury_start).toLocaleDateString()}</span>
                        <span className={`injury-status status-${(injury.recovery_status || '').toLowerCase().replace(/\s+/g, '-')}`}>
                          {injury.recovery_status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="no-injuries">✅ No injuries reported</div>
              )}
            </div>

            {/* Database Source Footer */}
            <div className="database-source-footer">
              <div className="source-badge">
                <span className="source-icon">💾</span>
                <div className="source-info">
                  <strong>Data Source: PostgreSQL Database</strong>
                  <small>Table: {sport === 'cricket' ? 'athletes, stats, injuries' : 'footballers, footballer_stats, footballer_injuries'}</small>
                </div>
              </div>
            </div>
          </div>
        )}

        {!playerDetails && !loadingDetails && !error && (
          <div className="no-selection">👈 Select a player to view details</div>
        )}
      </div>
    </div>
  );
}

export default PlayerSearch;
