import React, { useState, useEffect } from 'react';
import './App.css';
import PlayerSearch from './components/PlayerSearch';

function App() {
  const [activeSport, setActiveSport] = useState('cricket');
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const endpoint = activeSport === 'cricket'
        ? 'http://localhost:5000/api/athletes?limit=300'
        : 'http://localhost:5000/api/footballers?limit=300';

      const response = await fetch(endpoint);
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      if (activeSport === 'cricket') {
        setPlayers(data.athletes || []);
      } else {
        setPlayers(data.footballers || []);
      }
    } catch (error) {
      console.error('Error fetching players:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [activeSport]);

  return (
    <div className="app-container">
      <div className="header">
        <h1>🏆 Athlete Performance Tracker</h1>
        <div className="sport-buttons">
          <button
            className={`sport-btn ${activeSport === 'cricket' ? 'active' : ''}`}
            onClick={() => setActiveSport('cricket')}
          >
            🏏 Cricket
          </button>
          <button
            className={`sport-btn ${activeSport === 'football' ? 'active' : ''}`}
            onClick={() => setActiveSport('football')}
          >
            ⚽ Football
          </button>
        </div>
        <div className="player-count">
          {activeSport === 'cricket' ? '🏏' : '⚽'} <strong>{players.length}</strong> players loaded from database
        </div>
      </div>

      <div className="main-content">
        {loading ? (
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <p>Loading {activeSport} players...</p>
          </div>
        ) : error ? (
          <div className="error-container">
            <p>Error: {error}</p>
          </div>
        ) : (
          <PlayerSearch players={players} sport={activeSport} />
        )}
      </div>
    </div>
  );
}

export default App;
