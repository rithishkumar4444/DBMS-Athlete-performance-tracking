const API_BASE_URL = 'http://localhost:5000/api';

export const searchAthletes = async (name) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/athletes/search/${encodeURIComponent(name)}`
    );
    if (!response.ok) {
      throw new Error('Search failed');
    }
    return response.json();
  } catch (error) {
    console.error('Error searching athletes:', error);
    throw error;
  }
};

export const getAthletes = async (limit = 50) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/athletes?limit=${limit}`
    );
    if (!response.ok) {
      throw new Error('Failed to fetch athletes');
    }
    return response.json();
  } catch (error) {
    console.error('Error fetching athletes:', error);
    throw error;
  }
};

export const getAthleteById = async (id) => {
  try {
    const response = await fetch(`${API_BASE_URL}/athletes/${id}`);
    if (!response.ok) {
      throw new Error('Failed to fetch athlete details');
    }
    return response.json();
  } catch (error) {
    console.error('Error fetching athlete details:', error);
    throw error;
  }
};

export const searchFootballers = async (name) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/footballers/search/${encodeURIComponent(name)}`
    );
    if (!response.ok) {
      throw new Error('Search failed');
    }
    return response.json();
  } catch (error) {
    console.error('Error searching footballers:', error);
    throw error;
  }
};

export const getFootballers = async (limit = 50) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/footballers?limit=${limit}`
    );
    if (!response.ok) {
      throw new Error('Failed to fetch footballers');
    }
    return response.json();
  } catch (error) {
    console.error('Error fetching footballers:', error);
    throw error;
  }
};

export const getFootballerById = async (id) => {
  try {
    const response = await fetch(`${API_BASE_URL}/footballers/${id}`);
    if (!response.ok) {
      throw new Error('Failed to fetch footballer details');
    }
    return response.json();
  } catch (error) {
    console.error('Error fetching footballer details:', error);
    throw error;
  }
};
