const { cricketPool, footballPool } = require('./db');
const { generateAllCricketPlayers } = require('./data/cricketPlayers');
const { generateAllFootballPlayers } = require('./data/footballPlayers');
const statsGenerator = require('./utils/statsGenerator');

async function seedCricketDatabase() {
  const client = await cricketPool.connect();
  
  try {
    console.log('\n🏏 Starting Cricket Database Seeding...\n');
    
    await client.query('BEGIN');

    // Clear existing data
    await client.query('DELETE FROM injuries');
    await client.query('DELETE FROM stats');
    await client.query('DELETE FROM athletes');
    await client.query('ALTER SEQUENCE athletes_athlete_id_seq RESTART WITH 1');
    
    console.log('✅ Cleared existing cricket data');

    // Generate 300 cricket players
    const players = generateAllCricketPlayers();
    console.log(`📊 Generating comprehensive stats for ${players.length} cricket players...`);

    let count = 0;
    // Insert players with their stats
    for (const player of players) {
      // Insert athlete
      const athleteResult = await client.query(
        `INSERT INTO athletes (name, country, role, age) 
         VALUES ($1, $2, $3, $4) RETURNING athlete_id`,
        [player.name, player.country, player.role, player.age]
      );
      
      const athleteId = athleteResult.rows[0].athlete_id;

      // Generate comprehensive stats
      const stats = statsGenerator.generateCricketStats(player.role);
      
      // Insert stats for each format
      for (const stat of stats) {
        await client.query(
          `INSERT INTO stats (athlete_id, format, matches, runs, wickets, batting_avg, bowling_avg, strike_rate)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [athleteId, stat.format, stat.matches, stat.runs, stat.wickets, 
           stat.batting_avg, stat.bowling_avg, stat.strike_rate]
        );
      }

      // Generate injuries
      const injuries = statsGenerator.generateInjuries();
      for (const injury of injuries) {
        await client.query(
          `INSERT INTO injuries (athlete_id, injury_type, injury_start, injury_end, recovery_status, impact_level)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [athleteId, injury.injury_type, injury.injury_start, injury.injury_end, 
           injury.recovery_status, injury.impact_level]
        );
      }
      
      count++;
      if (count % 50 === 0) {
        console.log(`  ✅ Processed ${count}/${players.length} players...`);
      }
    }

    await client.query('COMMIT');
    console.log(`✅ Cricket database seeded successfully with ${players.length} players!\n`);

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Cricket seeding error:', error.message);
    throw error;
  } finally {
    client.release();
  }
}

async function seedFootballDatabase() {
  const client = await footballPool.connect();
  
  try {
    console.log('\n⚽ Starting Football Database Seeding...\n');
    
    await client.query('BEGIN');

    // Clear existing data
    await client.query('DELETE FROM footballer_injuries');
    await client.query('DELETE FROM footballer_stats');
    await client.query('DELETE FROM footballers');
    await client.query('ALTER SEQUENCE footballers_footballer_id_seq RESTART WITH 1');
    
    console.log('✅ Cleared existing football data');

    // Generate 300 football players
    const players = generateAllFootballPlayers();
    console.log(`📊 Generating comprehensive stats for ${players.length} football players...`);

    let count = 0;
    // Insert players and their stats
    for (const player of players) {
      // Insert footballer
      const footballerResult = await client.query(
        `INSERT INTO footballers (name, country, position, age) 
         VALUES ($1, $2, $3, $4) RETURNING footballer_id`,
        [player.name, player.country, player.position, player.age]
      );
      
      const footballerId = footballerResult.rows[0].footballer_id;

      // Generate comprehensive position-specific stats
      const stats = statsGenerator.generateFootballStats(player.position);
      
      // Insert stats for each season
      for (const stat of stats) {
        await client.query(
          `INSERT INTO footballer_stats (footballer_id, season, matches, goals, assists, clean_sheets, pass_accuracy, tackles, saves)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
          [footballerId, stat.season, stat.matches, stat.goals, stat.assists, 
           stat.clean_sheets, stat.pass_accuracy, 
           Math.floor(parseFloat(stat.tackles_per_game || 0) * stat.matches),
           stat.saves]
        );
      }

      // Generate injuries
      const injuries = statsGenerator.generateInjuries();
      for (const injury of injuries) {
        await client.query(
          `INSERT INTO footballer_injuries (footballer_id, injury_type, injury_start, injury_end, recovery_status)
           VALUES ($1, $2, $3, $4, $5)`,
          [footballerId, injury.injury_type, injury.injury_start, injury.injury_end, injury.recovery_status]
        );
      }
      
      count++;
      if (count % 50 === 0) {
        console.log(`  ✅ Processed ${count}/${players.length} players...`);
      }
    }

    await client.query('COMMIT');
    console.log(`✅ Football database seeded successfully with ${players.length} players!\n`);

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Football seeding error:', error.message);
    throw error;
  } finally {
    client.release();
  }
}

async function seedAllDatabases() {
  try {
    console.log('\n╔════════════════════════════════════════╗');
    console.log('║   DATABASE SEEDING WITH REAL DATA     ║');
    console.log('╚════════════════════════════════════════╝\n');

    await seedCricketDatabase();
    await seedFootballDatabase();

    console.log('\n╔════════════════════════════════════════╗');
    console.log('║   ✅ ALL DATABASES SEEDED SUCCESSFULLY ║');
    console.log('╚════════════════════════════════════════╝\n');

    process.exit(0);
  } catch (error) {
    console.error('\n❌ Seeding failed:', error);
    process.exit(1);
  }
}

// Run seeding
seedAllDatabases();
