const express = require('express');
const router = express.Router();
const { cricketPool } = require('../db');
const statsGenerator = require('../utils/statsGenerator');

// Get all athletes
router.get('/', async (req, res) => {
  try {
    const { limit = 50, offset = 0 } = req.query;
    const result = await cricketPool.query(
      `SELECT a.*, 
        COUNT(DISTINCT s.stat_id) as stats_count,
        COUNT(DISTINCT i.injury_id) as injury_count
       FROM athletes a
       LEFT JOIN stats s ON a.athlete_id = s.athlete_id
       LEFT JOIN injuries i ON a.athlete_id = i.athlete_id
       GROUP BY a.athlete_id, a.name, a.country, a.role, a.age
       ORDER BY a.name ASC 
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    res.json({ athletes: result.rows });
  } catch (err) {
    console.error('Cricket Query Error:', err);
    res.status(500).json({ error: 'Cricket DB Error: ' + err.message });
  }
});

// Get single athlete with detailed stats
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`[CRICKET] Fetching athlete ID: ${id}`);

    // Get athlete basic info
    const athleteResult = await cricketPool.query(
      `SELECT * FROM athletes WHERE athlete_id = $1`,
      [id]
    );

    if (athleteResult.rows.length === 0) {
      console.log(`[CRICKET] Athlete ${id} not found`);
      return res.status(404).json({ error: 'Athlete not found' });
    }

    const athlete = athleteResult.rows[0];
    console.log(`[CRICKET] Found athlete: ${athlete.name}`);

    // Get stats by format
    const statsResult = await cricketPool.query(
      `SELECT * FROM stats WHERE athlete_id = $1 ORDER BY format`,
      [id]
    );
    console.log(`[CRICKET] Found ${statsResult.rows.length} stat records`);

    // Get injuries
    const injuriesResult = await cricketPool.query(
      `SELECT * FROM injuries WHERE athlete_id = $1 ORDER BY injury_start DESC`,
      [id]
    );
    console.log(`[CRICKET] Found ${injuriesResult.rows.length} injury records`);

    // Calculate overall performance metrics
    const stats = statsResult.rows;
    let totalMatches = 0;
    let totalRuns = 0;
    let totalWickets = 0;
    let avgBattingAvg = 0;
    let avgBowlingAvg = 0;
    let avgStrikeRate = 0;

    if (stats && stats.length > 0) {
      stats.forEach(stat => {
        totalMatches += parseInt(stat.matches) || 0;
        totalRuns += parseInt(stat.runs) || 0;
        totalWickets += parseInt(stat.wickets) || 0;
        if (stat.batting_avg) avgBattingAvg += parseFloat(stat.batting_avg);
        if (stat.bowling_avg) avgBowlingAvg += parseFloat(stat.bowling_avg);
        if (stat.strike_rate) avgStrikeRate += parseFloat(stat.strike_rate);
      });

      const count = stats.length;
      avgBattingAvg = avgBattingAvg / count;
      avgBowlingAvg = avgBowlingAvg / count;
      avgStrikeRate = avgStrikeRate / count;
    }

    // Calculate performance rating (0-100)
    const battingRating = Math.min(Math.max((avgBattingAvg / 50) * 100, 0), 100);
    const bowlingRating = Math.max(0, 100 - (avgBowlingAvg / 50) * 100);
    const strikeRateRating = Math.min(Math.max((avgStrikeRate / 150) * 100, 0), 100);

    const overallPerformance = stats.length > 0 
      ? (battingRating + bowlingRating + strikeRateRating) / 3 
      : 0;

    // Calculate injury impact
    const injuries = injuriesResult.rows || [];
    const activeInjuries = injuries.filter(inj => {
      if (!inj.injury_end) return true;
      return new Date(inj.injury_end) > new Date();
    });

    let totalImpact = 0;
    activeInjuries.forEach(inj => {
      totalImpact += parseFloat(inj.impact_level) || 5;
    });

    const finalRating = Math.max(0, Math.min(100, overallPerformance - totalImpact));

    // Calculate comprehensive metrics with overall rating
    const ratings = statsGenerator.calculateOverallRating(stats, injuries, athlete.role);
    
    const responseData = {
      athlete_id: athlete.athlete_id,
      name: athlete.name,
      country: athlete.country,
      role: athlete.role,
      age: athlete.age,
      stats: stats && stats.length > 0 ? stats : [],
      injuries: injuries,
      metrics: {
        total_matches: totalMatches,
        total_runs: totalRuns,
        total_wickets: totalWickets,
        avg_batting: avgBattingAvg.toFixed(2),
        avg_bowling: avgBowlingAvg.toFixed(2),
        avg_strike_rate: avgStrikeRate.toFixed(2),
        batting_rating: battingRating.toFixed(2),
        bowling_rating: bowlingRating.toFixed(2),
        strike_rate_rating: strikeRateRating.toFixed(2),
        overall_performance: overallPerformance.toFixed(2),
        performance_score: ratings.performance_score,
        injury_impact: ratings.injury_impact,
        fitness_level: ratings.fitness_level,
        final_rating: ratings.overall_rating,
        // Role-specific metrics
        role_specific: athlete.role === 'Batter' || athlete.role === 'Wicket-keeper' ? {
          runs_per_match: totalMatches > 0 ? (totalRuns / totalMatches).toFixed(2) : 0,
          batting_avg: avgBattingAvg.toFixed(2)
        } : athlete.role === 'Bowler' ? {
          wickets_per_match: totalMatches > 0 ? (totalWickets / totalMatches).toFixed(2) : 0,
          bowling_avg: avgBowlingAvg.toFixed(2)
        } : {
          runs_per_match: totalMatches > 0 ? (totalRuns / totalMatches).toFixed(2) : 0,
          wickets_per_match: totalMatches > 0 ? (totalWickets / totalMatches).toFixed(2) : 0
        }
      }
    };

    console.log(`[CRICKET] Sending metrics:`, responseData.metrics);
    res.json(responseData);
  } catch (err) {
    console.error('Cricket Query Error:', err);
    res.status(500).json({ error: 'Cricket DB Error: ' + err.message });
  }
});

// Search athletes by name
router.get('/search/:name', async (req, res) => {
  try {
    const { name } = req.params;
    const result = await cricketPool.query(
      `SELECT * FROM athletes WHERE name ILIKE $1 ORDER BY name ASC LIMIT 20`,
      ['%' + name + '%']
    );
    res.json({ athletes: result.rows });
  } catch (err) {
    console.error('Cricket Query Error:', err);
    res.status(500).json({ error: 'Cricket DB Error: ' + err.message });
  }
});

module.exports = router;
