const express = require('express');
const router = express.Router();
const { footballPool } = require('../db');
const statsGenerator = require('../utils/statsGenerator');

// Get all footballers
router.get('/', async (req, res) => {
  try {
    const { limit = 50, offset = 0 } = req.query;
    const result = await footballPool.query(
      `SELECT f.*,
        COUNT(DISTINCT fs.stat_id) as stats_count,
        COUNT(DISTINCT fi.injury_id) as injury_count
       FROM footballers f
       LEFT JOIN footballer_stats fs ON f.footballer_id = fs.footballer_id
       LEFT JOIN footballer_injuries fi ON f.footballer_id = fi.footballer_id
       GROUP BY f.footballer_id, f.name, f.country, f.position, f.age
       ORDER BY f.name ASC
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    res.json({ footballers: result.rows });
  } catch (err) {
    console.error('Football Query Error:', err);
    res.status(500).json({ error: 'Football DB Error: ' + err.message });
  }
});

// Get single footballer with detailed stats
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`[FOOTBALL] Fetching footballer ID: ${id}`);

    // Get footballer basic info
    const footballerResult = await footballPool.query(
      `SELECT * FROM footballers WHERE footballer_id = $1`,
      [id]
    );

    if (footballerResult.rows.length === 0) {
      console.log(`[FOOTBALL] Footballer ${id} not found`);
      return res.status(404).json({ error: 'Footballer not found' });
    }

    const footballer = footballerResult.rows[0];
    console.log(`[FOOTBALL] Found footballer: ${footballer.name}`);

    // Get stats by season
    const statsResult = await footballPool.query(
      `SELECT * FROM footballer_stats WHERE footballer_id = $1 ORDER BY season DESC`,
      [id]
    );
    console.log(`[FOOTBALL] Found ${statsResult.rows.length} stat records`);

    // Get injuries
    const injuriesResult = await footballPool.query(
      `SELECT * FROM footballer_injuries WHERE footballer_id = $1 ORDER BY injury_start DESC`,
      [id]
    );
    console.log(`[FOOTBALL] Found ${injuriesResult.rows.length} injury records`);

    // Calculate overall performance metrics
    const stats = statsResult.rows || [];
    let totalMatches = 0;
    let totalGoals = 0;
    let totalAssists = 0;
    let totalCleanSheets = 0;
    let avgPassAccuracy = 0;
    let totalTackles = 0;
    let totalSaves = 0;

    if (stats && stats.length > 0) {
      stats.forEach(stat => {
        totalMatches += parseInt(stat.matches) || 0;
        totalGoals += parseInt(stat.goals) || 0;
        totalAssists += parseInt(stat.assists) || 0;
        totalCleanSheets += parseInt(stat.clean_sheets) || 0;
        if (stat.pass_accuracy) avgPassAccuracy += parseFloat(stat.pass_accuracy);
        totalTackles += parseInt(stat.tackles) || 0;
        totalSaves += parseInt(stat.saves) || 0;
      });

      avgPassAccuracy = avgPassAccuracy / stats.length;
    }

    // Calculate performance ratings (0-100)
    const goalsPerMatch = stats.length > 0 ? totalGoals / stats.length : 0;
    const goalsRating = Math.min(Math.max((goalsPerMatch / 0.5) * 100, 0), 100);

    const assistsPerMatch = stats.length > 0 ? totalAssists / stats.length : 0;
    const assistsRating = Math.min(Math.max((assistsPerMatch / 0.3) * 100, 0), 100);

    const passAccuracyRating = Math.min(Math.max(avgPassAccuracy || 0, 0), 100);

    const tacklesPerMatch = stats.length > 0 ? totalTackles / stats.length : 0;
    const defensiveRating = Math.min(Math.max((tacklesPerMatch / 5) * 100, 0), 100);

    // Overall performance based on position
    let overallPerformance = 0;
    const position = (footballer.position || '').toLowerCase();

    if (position.includes('goal')) {
      const cleanSheetRating = stats.length > 0 ? Math.min((totalCleanSheets / stats.length) * 100, 100) : 0;
      overallPerformance = (passAccuracyRating + defensiveRating + cleanSheetRating) / 3;
    } else if (position.includes('def')) {
      const cleanSheetRating = stats.length > 0 ? Math.min((totalCleanSheets / (stats.length * 10)) * 100, 100) : 0;
      overallPerformance = (defensiveRating + passAccuracyRating + cleanSheetRating) / 3;
    } else {
      overallPerformance = (goalsRating + assistsRating + passAccuracyRating) / 3;
    }

    // Calculate injury impact
    const injuries = injuriesResult.rows || [];
    const activeInjuries = injuries.filter(inj => {
      if (!inj.injury_end) return true;
      return new Date(inj.injury_end) > new Date();
    });

    let totalImpact = 0;
    activeInjuries.forEach(inj => {
      totalImpact += 5;
    });

    // Calculate comprehensive metrics with overall rating
    const ratings = statsGenerator.calculateOverallRating(stats, injuries, footballer.position);
    
    // Calculate position-specific averages
    let positionMetrics = {};
    if (stats.length > 0) {
      const avgMatches = totalMatches / stats.length;
      
      if (footballer.position === 'Forward') {
        positionMetrics = {
          goals_per_game: avgMatches > 0 ? (totalGoals / totalMatches).toFixed(2) : 0,
          assists_per_game: avgMatches > 0 ? (totalAssists / totalMatches).toFixed(2) : 0
        };
      } else if (footballer.position === 'Midfielder') {
        const totalPasses = stats.reduce((sum, s) => sum + (parseInt(s.tackles) || 0), 0);
        positionMetrics = {
          passes_per_game: avgMatches > 0 ? (totalPasses / totalMatches * 10).toFixed(2) : 0, // Estimate
          assists_per_game: avgMatches > 0 ? (totalAssists / totalMatches).toFixed(2) : 0
        };
      } else if (footballer.position === 'Defender') {
        positionMetrics = {
          tackles_per_game: avgMatches > 0 ? (totalTackles / totalMatches).toFixed(2) : 0,
          clean_sheets_percentage: avgMatches > 0 ? ((totalCleanSheets / totalMatches) * 100).toFixed(2) : 0
        };
      } else if (footballer.position === 'Goalkeeper') {
        positionMetrics = {
          saves_per_game: avgMatches > 0 ? (totalSaves / totalMatches).toFixed(2) : 0,
          clean_sheets_percentage: avgMatches > 0 ? ((totalCleanSheets / totalMatches) * 100).toFixed(2) : 0
        };
      }
    }
    
    const responseData = {
      footballer_id: footballer.footballer_id,
      name: footballer.name,
      country: footballer.country,
      position: footballer.position,
      age: footballer.age,
      stats: stats && stats.length > 0 ? stats : [],
      injuries: injuries,
      metrics: {
        total_matches: totalMatches,
        total_goals: totalGoals,
        total_assists: totalAssists,
        total_clean_sheets: totalCleanSheets,
        avg_pass_accuracy: avgPassAccuracy.toFixed(2),
        total_tackles: totalTackles,
        total_saves: totalSaves,
        goals_rating: goalsRating.toFixed(2),
        assists_rating: assistsRating.toFixed(2),
        pass_accuracy_rating: passAccuracyRating.toFixed(2),
        defensive_rating: defensiveRating.toFixed(2),
        overall_performance: overallPerformance.toFixed(2),
        performance_score: ratings.performance_score,
        injury_impact: ratings.injury_impact,
        fitness_level: ratings.fitness_level,
        final_rating: ratings.overall_rating,
        position_specific: positionMetrics
      }
    };

    console.log(`[FOOTBALL] Sending metrics:`, responseData.metrics);
    res.json(responseData);
  } catch (err) {
    console.error('Football Query Error:', err);
    res.status(500).json({ error: 'Football DB Error: ' + err.message });
  }
});

// Search footballers by name
router.get('/search/:name', async (req, res) => {
  try {
    const { name } = req.params;
    const result = await footballPool.query(
      `SELECT * FROM footballers WHERE name ILIKE $1 ORDER BY name ASC LIMIT 20`,
      ['%' + name + '%']
    );
    res.json({ footballers: result.rows });
  } catch (err) {
    console.error('Football Query Error:', err);
    res.status(500).json({ error: 'Football DB Error: ' + err.message });
  }
});

module.exports = router;
