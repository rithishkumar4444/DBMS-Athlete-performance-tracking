const { cricketPool, footballPool } = require('./db');
const fs = require('fs');
const path = require('path');

async function importSQLFiles() {
  console.log('\n╔════════════════════════════════════════╗');
  console.log('║   IMPORTING SQL FILES FROM DATABASE    ║');
  console.log('╚════════════════════════════════════════╝\n');

  // Import Cricket Data
  const cricketClient = await cricketPool.connect();
  try {
    console.log('🏏 Importing Cricket Performance Data...\n');
    
    const cricketSQL = fs.readFileSync(
      path.join(__dirname, '../database/cricket_performance_data.txt.sql'),
      'utf-8'
    );

    // Split by semicolon and execute each statement
    const statements = cricketSQL
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0 && !s.startsWith('--'));

    let count = 0;
    for (const statement of statements) {
      try {
        await cricketClient.query(statement);
        count++;
        if (count % 50 === 0) {
          console.log(`  ✅ Executed ${count} statements...`);
        }
      } catch (err) {
        // Skip errors for already existing data
        if (!err.message.includes('duplicate') && !err.message.includes('already exists')) {
          console.log(`  ⚠️  Skipped: ${err.message.substring(0, 60)}...`);
        }
      }
    }

    console.log(`\n✅ Cricket data imported successfully! (${count} statements executed)\n`);

  } catch (error) {
    console.error('❌ Cricket import error:', error.message);
  } finally {
    cricketClient.release();
  }

  // Import Football Data
  const footballClient = await footballPool.connect();
  try {
    console.log('⚽ Importing Football Performance Data...\n');
    
    const footballSQL = fs.readFileSync(
      path.join(__dirname, '../database/football_performance_data.sql'),
      'utf-8'
    );

    // Execute the entire SQL at once (it has proper structure)
    await footballClient.query(footballSQL);

    console.log(`\n✅ Football data imported successfully!\n`);

  } catch (error) {
    console.error('❌ Football import error:', error.message);
  } finally {
    footballClient.release();
  }

  console.log('\n╔════════════════════════════════════════╗');
  console.log('║   ✅ ALL SQL FILES IMPORTED            ║');
  console.log('╚════════════════════════════════════════╝\n');

  // Show counts
  try {
    const cricketCount = await cricketPool.query('SELECT COUNT(*) FROM athletes');
    const footballCount = await footballPool.query('SELECT COUNT(*) FROM footballers');
    
    console.log(`📊 Total Cricket Players: ${cricketCount.rows[0].count}`);
    console.log(`📊 Total Football Players: ${footballCount.rows[0].count}\n`);
  } catch (err) {
    console.log('Could not retrieve counts');
  }

  process.exit(0);
}

importSQLFiles().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
