const { cricketPool, footballPool } = require('./db');

// Realistic injury types
const injuryTypes = [
  'Hamstring Strain', 'Ankle Sprain', 'Knee Injury', 'Groin Strain',
  'Calf Strain', 'Back Spasm', 'Shoulder Injury', 'Thigh Injury',
  'ACL Tear', 'Meniscus Tear', 'Muscle Tear', 'Hip Flexor',
  'Achilles Injury', 'Concussion', 'Wrist Injury', 'Rib Injury',
  'Foot Fracture', 'Quadriceps Strain', 'Adductor Strain', 'Ligament Damage'
];

const recoveryStatuses = ['Fully Recovered', 'Recovered', 'Fit', 'In Recovery', 'Under Treatment', 'Rehabilitation'];

// Calculate fitness level based on injuries
function calculateFitnessLevel(injuries) {
  if (!injuries || injuries.length === 0) return 100;
  
  let impactSum = 0;
  let activeInjuries = 0;
  
  injuries.forEach(injury => {
    const impact = parseFloat(injury.impact_level) || 5;
    if (injury.recovery_status !== 'Fully Recovered' && injury.recovery_status !== 'Recovered' && injury.recovery_status !== 'Fit') {
      activeInjuries++;
      impactSum += impact * 1.5; // Active injuries have more impact
    } else {
      impactSum += impact * 0.3; // Recovered injuries have minimal impact
    }
  });
  
  const fitnessLevel = Math.max(60, Math.min(100, 100 - impactSum));
  return parseFloat(fitnessLevel.toFixed(1));
}

// Generate realistic injury if player has none
function generateRealisticInjury(hasExisting) {
  // 70% chance of having at least one injury
  if (hasExisting || Math.random() > 0.3) {
    const daysAgo = Math.floor(Math.random() * 730); // Within last 2 years
    const injuryStart = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000);
    const recoveryDays = Math.floor(Math.random() * 120) + 14; // 14-134 days recovery
    const isRecovered = daysAgo > recoveryDays;
    const injuryEnd = isRecovered ? new Date(injuryStart.getTime() + recoveryDays * 24 * 60 * 60 * 1000) : null;
    
    return {
      injury_type: injuryTypes[Math.floor(Math.random() * injuryTypes.length)],
      injury_start: injuryStart.toISOString().split('T')[0],
      injury_end: injuryEnd ? injuryEnd.toISOString().split('T')[0] : null,
      recovery_status: isRecovered ? recoveryStatuses[Math.floor(Math.random() * 3)] : recoveryStatuses[Math.floor(Math.random() * 3) + 3],
      impact_level: (Math.random() * 7 + 2).toFixed(1) // 2.0 - 9.0
    };
  }
  return null;
}

async function updateFootballInjuriesAndFitness() {
  const client = await footballPool.connect();
  
  try {
    console.log('\n⚽ Updating Football Players - Injuries & Fitness...\n');
    
    // Get all footballers
    const result = await client.query('SELECT footballer_id FROM footballers ORDER BY footballer_id');
    const footballers = result.rows;
    
    let updatedCount = 0;
    let addedInjuries = 0;
    
    for (const footballer of footballers) {
      const footballerId = footballer.footballer_id;
      
      // Check existing injuries
      const injuriesResult = await client.query(
        'SELECT * FROM footballer_injuries WHERE footballer_id = $1',
        [footballerId]
      );
      
      const existingInjuries = injuriesResult.rows;
      
      // Add injury if player has none or randomly add second injury (20% chance)
      if (existingInjuries.length === 0 || (existingInjuries.length === 1 && Math.random() > 0.8)) {
        const newInjury = generateRealisticInjury(existingInjuries.length > 0);
        if (newInjury) {
          await client.query(
            `INSERT INTO footballer_injuries (footballer_id, injury_type, injury_start, injury_end, recovery_status)
             VALUES ($1, $2, $3, $4, $5)`,
            [footballerId, newInjury.injury_type, newInjury.injury_start, newInjury.injury_end, newInjury.recovery_status]
          );
          addedInjuries++;
        }
      }
      
      // Update impact_level for existing injuries if missing
      for (const injury of existingInjuries) {
        if (!injury.impact_level) {
          const impact = (Math.random() * 7 + 2).toFixed(1);
          await client.query(
            'UPDATE footballer_injuries SET impact_level = $1 WHERE injury_id = $2',
            [impact, injury.injury_id]
          );
        }
      }
      
      updatedCount++;
      if (updatedCount % 50 === 0) {
        console.log(`  ✅ Processed ${updatedCount}/${footballers.length} players...`);
      }
    }
    
    console.log(`\n✅ Updated ${updatedCount} football players`);
    console.log(`📋 Added ${addedInjuries} new injuries\n`);
    
  } catch (error) {
    console.error('❌ Error updating football data:', error.message);
  } finally {
    client.release();
  }
}

async function updateCricketInjuriesAndFitness() {
  const client = await cricketPool.connect();
  
  try {
    console.log('\n🏏 Updating Cricket Players - Injuries & Fitness...\n');
    
    // Get all athletes
    const result = await client.query('SELECT athlete_id FROM athletes ORDER BY athlete_id');
    const athletes = result.rows;
    
    let updatedCount = 0;
    let addedInjuries = 0;
    
    for (const athlete of athletes) {
      const athleteId = athlete.athlete_id;
      
      // Check existing injuries
      const injuriesResult = await client.query(
        'SELECT * FROM injuries WHERE athlete_id = $1',
        [athleteId]
      );
      
      const existingInjuries = injuriesResult.rows;
      
      // Add injury if player has none or randomly add second injury (20% chance)
      if (existingInjuries.length === 0 || (existingInjuries.length === 1 && Math.random() > 0.8)) {
        const newInjury = generateRealisticInjury(existingInjuries.length > 0);
        if (newInjury) {
          await client.query(
            `INSERT INTO injuries (athlete_id, injury_type, injury_start, injury_end, recovery_status, impact_level)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [athleteId, newInjury.injury_type, newInjury.injury_start, newInjury.injury_end, 
             newInjury.recovery_status, newInjury.impact_level]
          );
          addedInjuries++;
        }
      }
      
      // Update impact_level for existing injuries if missing
      for (const injury of existingInjuries) {
        if (!injury.impact_level) {
          const impact = (Math.random() * 7 + 2).toFixed(1);
          await client.query(
            'UPDATE injuries SET impact_level = $1 WHERE injury_id = $2',
            [impact, injury.injury_id]
          );
        }
      }
      
      updatedCount++;
      if (updatedCount % 50 === 0) {
        console.log(`  ✅ Processed ${updatedCount}/${athletes.length} players...`);
      }
    }
    
    console.log(`\n✅ Updated ${updatedCount} cricket players`);
    console.log(`📋 Added ${addedInjuries} new injuries\n`);
    
  } catch (error) {
    console.error('❌ Error updating cricket data:', error.message);
  } finally {
    client.release();
  }
}

async function main() {
  console.log('\n╔════════════════════════════════════════╗');
  console.log('║  UPDATING INJURY & FITNESS DATA       ║');
  console.log('╚════════════════════════════════════════╝\n');
  
  await updateCricketInjuriesAndFitness();
  await updateFootballInjuriesAndFitness();
  
  console.log('\n╔════════════════════════════════════════╗');
  console.log('║  ✅ ALL UPDATES COMPLETED              ║');
  console.log('╚════════════════════════════════════════╝\n');
  
  process.exit(0);
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
