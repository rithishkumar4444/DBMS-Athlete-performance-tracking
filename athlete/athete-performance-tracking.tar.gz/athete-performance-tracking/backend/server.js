const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Import both pools from db.js
const { cricketPool, footballPool } = require('./db');

// Test Cricket Connection
cricketPool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('❌ Cricket DB error:', err);
  } else {
    console.log('✅ Cricket DB connected');
  }
});

// Test Football Connection
footballPool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('❌ Football DB error:', err);
  } else {
    console.log('✅ Football DB connected');
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK' });
});

// Import routes
const athleteRoutes = require('./routes/athletes');
const footballerRoutes = require('./routes/footballers');

app.use('/api/athletes', athleteRoutes);
app.use('/api/footballers', footballerRoutes);

// Error handlers
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Server error' });
});

app.listen(PORT, () => {
  console.log('');
  console.log('╔════════════════════════════════════════╗');
  console.log('║  ⚽🏏 SPORTS API RUNNING              ║');
  console.log('╚════════════════════════════════════════╝');
  console.log(`🏏 Cricket: http://localhost:${PORT}/api/athletes`);
  console.log(`⚽ Football: http://localhost:${PORT}/api/footballers`);
  console.log('');
});

module.exports = app;
