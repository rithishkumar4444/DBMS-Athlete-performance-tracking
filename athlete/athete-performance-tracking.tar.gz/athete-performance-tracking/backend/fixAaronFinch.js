const { cricketPool } = require('./db');

async function fixAaronFinch() {
  try {
    console.log('Updating Aaron Finch role...');
    
    await cricketPool.query(
      "UPDATE athletes SET role = 'batter' WHERE name = 'Aaron Finch'"
    );
    
    const result = await cricketPool.query(
      "SELECT name, role, country FROM athletes WHERE name = 'Aaron Finch'"
    );
    
    console.log('✅ Updated successfully:');
    console.log(result.rows[0]);
    
    process.exit(0);
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  }
}

fixAaronFinch();
