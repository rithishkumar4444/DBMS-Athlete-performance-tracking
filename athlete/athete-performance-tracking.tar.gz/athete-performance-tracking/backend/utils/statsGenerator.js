// Comprehensive Stats Generator with Position-Specific Metrics

class StatsGenerator {
  
  // Generate cricket stats based on role
  generateCricketStats(role) {
    const formats = ['TEST', 'ODI', 'T20'];
    
    return formats.map(format => {
      const stats = {
        format,
        matches: Math.floor(Math.random() * 100) + 30,
        runs: 0,
        wickets: 0,
        batting_avg: 0,
        bowling_avg: 0,
        strike_rate: 0,
        catches: 0,
        stumping: 0
      };

      if (role === 'Batter' || role === 'All-rounder' || role === 'Wicket-keeper') {
        const baseRuns = format === 'TEST' ? 5000 : format === 'ODI' ? 3500 : 1800;
        stats.runs = Math.floor(Math.random() * baseRuns + 1000);
        stats.batting_avg = (Math.random() * 25 + 30).toFixed(2);
        stats.strike_rate = format === 'TEST' ? (Math.random() * 30 + 45).toFixed(2) : 
                           format === 'ODI' ? (Math.random() * 30 + 75).toFixed(2) : 
                           (Math.random() * 40 + 120).toFixed(2);
        stats.catches = Math.floor(Math.random() * 50) + 10;
      }

      if (role === 'Bowler' || role === 'All-rounder') {
        const baseWickets = format === 'TEST' ? 250 : format === 'ODI' ? 180 : 100;
        stats.wickets = Math.floor(Math.random() * baseWickets + 30);
        stats.bowling_avg = (Math.random() * 10 + 22).toFixed(2);
        stats.strike_rate = format === 'TEST' ? (Math.random() * 20 + 45).toFixed(2) : 
                           format === 'ODI' ? (Math.random() * 15 + 30).toFixed(2) : 
                           (Math.random() * 10 + 18).toFixed(2);
      }

      if (role === 'Wicket-keeper') {
        stats.catches = Math.floor(Math.random() * 100) + 50;
        stats.stumping = Math.floor(Math.random() * 30) + 5;
      }

      return stats;
    });
  }

  // Generate football stats based on position  
  generateFootballStats(position) {
    const seasons = ['2022-23', '2023-24', '2024-25'];
    
    return seasons.map(season => {
      const stats = {
        season,
        matches: Math.floor(Math.random() * 25) + 20,
        goals: 0,
        assists: 0,
        clean_sheets: 0,
        pass_accuracy: 0,
        tackles_per_game: 0,
        passes_per_game: 0,
        goals_per_game: 0,
        saves: 0,
        interceptions: 0
      };

      switch (position) {
        case 'Forward':
          stats.goals = Math.floor(Math.random() * 25) + 8;
          stats.assists = Math.floor(Math.random() * 12) + 3;
          stats.goals_per_game = (stats.goals / stats.matches).toFixed(2);
          stats.pass_accuracy = (Math.random() * 15 + 70).toFixed(2);
          stats.tackles_per_game = (Math.random() * 1 + 0.5).toFixed(2);
          stats.passes_per_game = Math.floor(Math.random() * 20) + 20;
          break;
        
        case 'Midfielder':
          stats.goals = Math.floor(Math.random() * 10) + 2;
          stats.assists = Math.floor(Math.random() * 15) + 5;
          stats.passes_per_game = Math.floor(Math.random() * 40) + 50;
          stats.pass_accuracy = (Math.random() * 10 + 80).toFixed(2);
          stats.tackles_per_game = (Math.random() * 2 + 1.5).toFixed(2);
          stats.interceptions = Math.floor(Math.random() * 40) + 20;
          break;
        
        case 'Defender':
          stats.goals = Math.floor(Math.random() * 4) + 1;
          stats.assists = Math.floor(Math.random() * 5) + 1;
          stats.clean_sheets = Math.floor(Math.random() * 15) + 8;
          stats.tackles_per_game = (Math.random() * 3 + 3).toFixed(2);
          stats.pass_accuracy = (Math.random() * 10 + 78).toFixed(2);
          stats.passes_per_game = Math.floor(Math.random() * 30) + 40;
          stats.interceptions = Math.floor(Math.random() * 60) + 40;
          break;
        
        case 'Goalkeeper':
          stats.saves = Math.floor(Math.random() * 80) + 60;
          stats.clean_sheets = Math.floor(Math.random() * 18) + 10;
          stats.pass_accuracy = (Math.random() * 20 + 60).toFixed(2);
          stats.passes_per_game = Math.floor(Math.random() * 20) + 15;
          break;
      }

      return stats;
    });
  }

  // Generate injuries with recovery status
  generateInjuries() {
    const injuryTypes = [
      'Hamstring Strain', 'Ankle Sprain', 'Knee Injury', 'Muscle Tear',
      'Groin Injury', 'Shoulder Injury', 'Back Spasm', 'Finger Fracture',
      'Calf Strain', 'Concussion', 'ACL Tear', 'Meniscus Tear'
    ];

    const recoveryStatuses = ['Fully Recovered', 'In Recovery', 'Rehabilitation', 'Return to Training'];
    
    // 40% chance of having injury history
    if (Math.random() > 0.6) {
      const numInjuries = Math.random() > 0.7 ? 2 : 1;
      const injuries = [];
      
      for (let i = 0; i < numInjuries; i++) {
        const daysAgo = Math.floor(Math.random() * 365);
        const injuryStart = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000);
        const recoveryDays = Math.floor(Math.random() * 90) + 14;
        const injuryEnd = daysAgo > recoveryDays ? new Date(injuryStart.getTime() + recoveryDays * 24 * 60 * 60 * 1000) : null;
        const isRecovered = !!injuryEnd;
        
        injuries.push({
          injury_type: injuryTypes[Math.floor(Math.random() * injuryTypes.length)],
          injury_start: injuryStart.toISOString().split('T')[0],
          injury_end: injuryEnd ? injuryEnd.toISOString().split('T')[0] : null,
          recovery_status: isRecovered ? 'Fully Recovered' : recoveryStatuses[Math.floor(Math.random() * recoveryStatuses.length)],
          impact_level: (Math.random() * 8 + 2).toFixed(1),
          recovery_percentage: isRecovered ? 100 : Math.floor(Math.random() * 40 + 40)
        });
      }
      
      return injuries;
    }
    return [];
  }

  // Calculate overall rating out of 100
  calculateOverallRating(stats, injuries, role_or_position) {
    let performanceScore = 0;
    let injuryImpact = 0;
    let fitnessLevel = 100; // Start with perfect fitness
    
    // Calculate injury impact and fitness level based on actual database data
    if (injuries && injuries.length > 0) {
      let activeInjuryCount = 0;
      let recoveredInjuryCount = 0;
      let totalRecoveryDays = 0;
      let severityMultiplier = 1;
      
      injuries.forEach(injury => {
        const impactLevel = parseFloat(injury.impact_level) || 5;
        const recoveryStatus = (injury.recovery_status || '').toLowerCase();
        const injuryType = (injury.injury_type || '').toLowerCase();
        
        // Determine severity multiplier based on injury type
        if (injuryType.includes('acl') || injuryType.includes('fracture') || injuryType.includes('meniscus')) {
          severityMultiplier = 1.8; // Major injuries
        } else if (injuryType.includes('tear') || injuryType.includes('ligament') || injuryType.includes('concussion')) {
          severityMultiplier = 1.5; // Serious injuries
        } else if (injuryType.includes('strain') || injuryType.includes('sprain') || injuryType.includes('groin')) {
          severityMultiplier = 1.2; // Moderate injuries
        } else {
          severityMultiplier = 0.9; // Minor injuries
        }
        
        // Check if injury is recovered/fit
        if (recoveryStatus.includes('recovered') || recoveryStatus.includes('fit')) {
          recoveredInjuryCount++;
          
          // Calculate days since recovery
          if (injury.injury_end) {
            const recoveryDate = new Date(injury.injury_end);
            const daysSinceRecovery = Math.floor((Date.now() - recoveryDate.getTime()) / (1000 * 60 * 60 * 24));
            totalRecoveryDays += daysSinceRecovery;
            
            // Recent recoveries still have residual impact
            if (daysSinceRecovery < 30) {
              injuryImpact += (impactLevel * 0.5 * severityMultiplier); // 50% impact for very recent
            } else if (daysSinceRecovery < 90) {
              injuryImpact += (impactLevel * 0.25 * severityMultiplier); // 25% impact for recent
            } else if (daysSinceRecovery < 180) {
              injuryImpact += (impactLevel * 0.1 * severityMultiplier); // 10% impact for medium-term
            } else {
              injuryImpact += (impactLevel * 0.05 * severityMultiplier); // 5% impact for long-term
            }
          } else {
            // No end date but recovered - assume 6 months ago
            injuryImpact += (impactLevel * 0.1 * severityMultiplier);
          }
        } else {
          // Active injury - full performance impact
          activeInjuryCount++;
          
          // Calculate time since injury started
          let daysSinceInjury = 0;
          if (injury.injury_start) {
            const injuryDate = new Date(injury.injury_start);
            daysSinceInjury = Math.floor((Date.now() - injuryDate.getTime()) / (1000 * 60 * 60 * 24));
          }
          
          // Recent active injuries have more impact
          if (recoveryStatus.includes('rehabilitation') || recoveryStatus.includes('recovery')) {
            // In rehabilitation - moderate impact
            injuryImpact += (impactLevel * 1.2 * severityMultiplier);
          } else if (recoveryStatus.includes('treatment')) {
            // Under treatment - high impact
            injuryImpact += (impactLevel * 1.5 * severityMultiplier);
          } else {
            // General active injury
            if (daysSinceInjury < 14) {
              injuryImpact += (impactLevel * 1.8 * severityMultiplier); // Acute phase
            } else if (daysSinceInjury < 60) {
              injuryImpact += (impactLevel * 1.4 * severityMultiplier); // Early recovery
            } else {
              injuryImpact += (impactLevel * 1.1 * severityMultiplier); // Extended recovery
            }
          }
        }
      });
      
      // Calculate fitness level independently
      if (activeInjuryCount > 0) {
        // Active injuries: 60-85% fitness based on severity and count
        const avgActiveImpact = injuries
          .filter(inj => {
            const status = (inj.recovery_status || '').toLowerCase();
            return !status.includes('recovered') && !status.includes('fit');
          })
          .reduce((sum, inj) => sum + (parseFloat(inj.impact_level) || 5), 0) / activeInjuryCount;
        
        fitnessLevel = Math.max(60, 95 - (avgActiveImpact * activeInjuryCount * severityMultiplier * 2));
      } else if (recoveredInjuryCount > 0) {
        // Recovered injuries: 82-98% fitness based on recovery time
        const avgDaysSinceRecovery = totalRecoveryDays / recoveredInjuryCount;
        
        if (avgDaysSinceRecovery > 180) {
          fitnessLevel = 95 + Math.random() * 3; // 95-98% for long-term recovery
        } else if (avgDaysSinceRecovery > 90) {
          fitnessLevel = 90 + Math.random() * 5; // 90-95% for medium-term
        } else if (avgDaysSinceRecovery > 30) {
          fitnessLevel = 85 + Math.random() * 5; // 85-90% for recent recovery
        } else {
          fitnessLevel = 78 + Math.random() * 7; // 78-85% for very recent
        }
      }
      
      // Add some natural variation for no injuries
      if (activeInjuryCount === 0 && recoveredInjuryCount === 0) {
        fitnessLevel = 94 + Math.random() * 6; // 94-100% natural fitness variation
      }
    } else {
      // No injury history: 94-100% fitness (natural variation)
      fitnessLevel = 94 + Math.random() * 6;
    }

    // Calculate performance score based on stats
    if (stats && stats.length > 0) {
      const avgStats = stats.reduce((acc, stat) => {
        Object.keys(stat).forEach(key => {
          const value = stat[key];
          if (typeof value === 'number' || (typeof value === 'string' && !isNaN(parseFloat(value)))) {
            acc[key] = (acc[key] || 0) + (parseFloat(value) || 0);
          }
        });
        return acc;
      }, {});

      // Normalize by number of formats/seasons
      Object.keys(avgStats).forEach(key => {
        avgStats[key] = avgStats[key] / stats.length;
      });

      console.log(`[STATS] Role: ${role_or_position}, batting_avg: ${avgStats.batting_avg}, strike_rate: ${avgStats.strike_rate}`);

      // Position/Role specific scoring
      if (role_or_position === 'Batter' || role_or_position === 'Wicket-keeper' || role_or_position === 'batter' || role_or_position === 'wicketkeeper') {
        const battingAvg = avgStats.batting_avg || 0;
        const strikeRate = avgStats.strike_rate || 0;
        // Batting average contributes more weight
        performanceScore = Math.min(100, (battingAvg * 1.2) + (strikeRate * 0.2));
      } else if (role_or_position === 'Bowler' || role_or_position === 'bowler') {
        const wickets = avgStats.wickets || 0;
        const bowlingAvg = avgStats.bowling_avg || 50;
        // Wickets and bowling average both important
        const wicketsScore = Math.min(60, wickets * 2);
        const avgScore = Math.max(0, 40 - (bowlingAvg - 15));
        performanceScore = Math.min(100, wicketsScore + avgScore);
      } else if (role_or_position === 'All-rounder' || role_or_position === 'allrounder') {
        const battingAvg = avgStats.batting_avg || 0;
        const wickets = avgStats.wickets || 0;
        performanceScore = Math.min(100, (battingAvg * 0.8) + (wickets * 1.5));
      } else if (role_or_position === 'Forward') {
        const goals = avgStats.goals || 0;
        const assists = avgStats.assists || 0;
        performanceScore = Math.min(100, (goals * 2.5) + (assists * 1.5));
      } else if (role_or_position === 'Midfielder') {
        const goals = avgStats.goals || 0;
        const assists = avgStats.assists || 0;
        const tackles = avgStats.tackles || 0;
        performanceScore = Math.min(100, (goals * 2) + (assists * 3) + (tackles * 0.3));
      } else if (role_or_position === 'Defender') {
        const tackles = avgStats.tackles || 0;
        const cleanSheets = avgStats.clean_sheets || 0;
        performanceScore = Math.min(100, (tackles * 0.8) + (cleanSheets * 3));
      } else if (role_or_position === 'Goalkeeper') {
        const saves = avgStats.saves || 0;
        const cleanSheets = avgStats.clean_sheets || 0;
        performanceScore = Math.min(100, (saves * 0.5) + (cleanSheets * 4));
      }
      
      // Ensure minimum performance score of 30 if player has stats
      if (performanceScore > 0 && performanceScore < 30) {
        performanceScore = 30;
      }
    }
    
    // Final rating = Performance - Injury Impact (cap injury impact at 40 max to avoid negative ratings)
    const cappedInjuryImpact = Math.min(injuryImpact, 40);
    const finalRating = Math.max(0, Math.min(100, performanceScore - cappedInjuryImpact));
    
    return {
      overall_rating: finalRating.toFixed(2),
      performance_score: performanceScore.toFixed(2),
      injury_impact: injuryImpact.toFixed(2),
      fitness_level: fitnessLevel.toFixed(2)
    };
  }
}

module.exports = new StatsGenerator();
