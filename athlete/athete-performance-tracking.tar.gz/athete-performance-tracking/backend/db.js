const { Pool } = require('pg');

// Cricket Database Pool
const cricketPool = new Pool({
  user: 'postgres',
  password: 'Postgres',
  host: 'localhost',
  port: 5432,
  database: 'cricket_performance'
});

// Football Database Pool
const footballPool = new Pool({
  user: 'postgres',
  password: 'Postgres',
  host: 'localhost',
  port: 5432,
  database: 'football_performance'
});

// Test Cricket Connection
cricketPool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('❌ Cricket DB Connection Error:', err.message);
  } else {
    console.log('✅ Cricket Database Connected Successfully');
  }
});

// Test Football Connection
footballPool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('❌ Football DB Connection Error:', err.message);
  } else {
    console.log('✅ Football Database Connected Successfully');
  }
});

module.exports = { cricketPool, footballPool };