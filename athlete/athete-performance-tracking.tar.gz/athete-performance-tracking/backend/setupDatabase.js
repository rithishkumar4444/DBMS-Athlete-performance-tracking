const { Pool } = require('pg');

// Connect to default 'postgres' database to create new databases
const adminPool = new Pool({
  user: 'postgres',
  password: 'Postgres',
  host: 'localhost',
  port: 5432,
  database: 'postgres'
});

async function createDatabases() {
  try {
    console.log('\n📦 Creating databases...\n');

    // Create cricket database
    try {
      await adminPool.query('CREATE DATABASE cricket_performance');
      console.log('✅ Created cricket_performance database');
    } catch (error) {
      if (error.code === '42P04') {
        console.log('ℹ️  cricket_performance database already exists');
      } else {
        throw error;
      }
    }

    // Create football database
    try {
      await adminPool.query('CREATE DATABASE football_performance');
      console.log('✅ Created football_performance database');
    } catch (error) {
      if (error.code === '42P04') {
        console.log('ℹ️  football_performance database already exists');
      } else {
        throw error;
      }
    }

    await adminPool.end();
    
    // Now create tables
    await createTables();

  } catch (error) {
    console.error('❌ Error creating databases:', error.message);
    process.exit(1);
  }
}

async function createTables() {
  console.log('\n📋 Creating tables...\n');

  // Cricket tables
  const cricketPool = new Pool({
    user: 'postgres',
    password: 'Postgres',
    host: 'localhost',
    port: 5432,
    database: 'cricket_performance'
  });

  try {
    await cricketPool.query(`
      CREATE TABLE IF NOT EXISTS athletes (
        athlete_id SERIAL PRIMARY KEY,
        name VARCHAR(100),
        country VARCHAR(50),
        role VARCHAR(30),
        age INT
      );

      CREATE TABLE IF NOT EXISTS stats (
        stat_id SERIAL PRIMARY KEY,
        athlete_id INT REFERENCES athletes(athlete_id) ON DELETE CASCADE,
        format VARCHAR(10),
        matches INT,
        runs INT,
        wickets INT,
        batting_avg DECIMAL(5,2),
        bowling_avg DECIMAL(5,2),
        strike_rate DECIMAL(6,2)
      );

      CREATE TABLE IF NOT EXISTS injuries (
        injury_id SERIAL PRIMARY KEY,
        athlete_id INT REFERENCES athletes(athlete_id) ON DELETE CASCADE,
        injury_type VARCHAR(100),
        injury_start DATE,
        injury_end DATE,
        recovery_status VARCHAR(30),
        impact_level DECIMAL(3,1)
      );
    `);
    console.log('✅ Created cricket tables');
  } catch (error) {
    console.error('❌ Error creating cricket tables:', error.message);
  } finally {
    await cricketPool.end();
  }

  // Football tables
  const footballPool = new Pool({
    user: 'postgres',
    password: 'Postgres',
    host: 'localhost',
    port: 5432,
    database: 'football_performance'
  });

  try {
    await footballPool.query(`
      CREATE TABLE IF NOT EXISTS footballers (
        footballer_id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        country VARCHAR(50),
        position VARCHAR(30),
        age INT
      );

      CREATE TABLE IF NOT EXISTS footballer_stats (
        stat_id SERIAL PRIMARY KEY,
        footballer_id INT NOT NULL REFERENCES footballers(footballer_id) ON DELETE CASCADE,
        season VARCHAR(20),
        matches INT DEFAULT 0,
        goals INT DEFAULT 0,
        assists INT DEFAULT 0,
        clean_sheets INT DEFAULT 0,
        pass_accuracy DECIMAL(5,2),
        tackles INT DEFAULT 0,
        saves INT DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS footballer_injuries (
        injury_id SERIAL PRIMARY KEY,
        footballer_id INT NOT NULL REFERENCES footballers(footballer_id) ON DELETE CASCADE,
        injury_type VARCHAR(100),
        injury_start DATE,
        injury_end DATE,
        recovery_status VARCHAR(50)
      );
    `);
    console.log('✅ Created football tables');
  } catch (error) {
    console.error('❌ Error creating football tables:', error.message);
  } finally {
    await footballPool.end();
  }

  console.log('\n✅ Database setup complete!\n');
  process.exit(0);
}

createDatabases();
